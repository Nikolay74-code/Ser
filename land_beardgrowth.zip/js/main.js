


$(document).ready(function() {
	
	$(".close-m1").click(function(){
		$("#m1-form").hide();
	});


	/* timer */
	now = new Date();
	var tomorrow = new Date().setHours(24, 0, 0);
	var now = new Date();
	var seconds = parseInt(tomorrow - now) / 1000;
	$(".el-timer").attr("data-timer", seconds);
	$(".el-timer").TimeCircles({
		"animation": "smooth",
		"bg_width": 1,
		"fg_width": 0.04,
		"circle_bg_color": "#262626",
		"time": {
			"Days": {
				"text": "",
				"color": "#facb55",
				"show": false
			},
			"Hours": {
				"text": "",
				"color": "#facb55",
				"show": true
			},
			"Minutes": {
				"text": "",
				"color": "#facb55",
				"show": true
			},
			"Seconds": {
				"text": "",
				"color": "#facb55",
				"show": true
			}
		}
	}); 

});



$(document).ready(function(){$(".button-arrows").on("click","a",function(event){event.preventDefault();var id=$(this).attr('href'),top=$(id).offset().top;$('body,html').animate({scrollTop:top},1500);});});
$(document).ready(function(){$('.open-order-form').on('click',function(event){event.preventDefault();$('#m1-form').css({display:'block'});});});
